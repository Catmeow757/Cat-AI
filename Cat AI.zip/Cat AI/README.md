READ BEFORE USING CAT AI!

Your antivirus might call it 'suspicious' beacuse it uses os.startfile()
run Cat_AI.bat and Cat_AI+.bat before using to set up the environment for it.
when you say something that is not do a mah equation to Cat AI, it will launch Cat AI+.
if you don't know what you can say to the AI, open Responses.txt